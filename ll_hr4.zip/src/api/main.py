from fastapi import FastAPI
from src.api.routes import users, sessions, sets
from src.repository.db import db_init_db

app = FastAPI(title="lift_log API")

@app.on_event("startup")
def startup():
    db_init_db()

app.include_router(users.router)
app.include_router(sessions.router)
app.include_router(sets.router)