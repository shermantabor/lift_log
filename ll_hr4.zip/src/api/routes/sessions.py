from fastapi import APIRouter
from src.api.schemas import SessionCreate, SessionResponse
from src.services.api_services import create_session, end_active_session

router = APIRouter(tags=["sessions"])

@router.post("/users/{user_id}/sessions", response_model=SessionResponse, status_code=201)
def post_session(user_id: int, session: SessionCreate):
    performed_at = session.performed_at.isoformat(timespec="seconds") if session.performed_at else None
    return create_session(user_id, performed_at, session.notes)

@router.post("/users/{user_id}/sessions/end")
def end_session(user_id: int):
    return end_active_session(user_id)
