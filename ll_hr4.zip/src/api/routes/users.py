from fastapi import APIRouter
from src.api.schemas import UserCreate, UserResponse
from src.services.api_services import create_user

router = APIRouter(prefix="/users", tags=["users"])

@router.post("", response_model=UserResponse, status_code=201)
def post_user(user: UserCreate):
    return create_user(user.username)